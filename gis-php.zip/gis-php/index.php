<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A==" crossorigin="" />
<script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js" integrity="sha512-XQoYMqMTK8LvdxXYG3nZ448hOEQiglfqkJs1NOQV44cWnUrBc8PkAOcXy20w0vlaXaVUearIOBhiXZ5V3ynxwA==" crossorigin=""></script>
    <title>GIS</title>
  </head>

    <header>
        <div class="navbar navbar-expand-md navbar-dark bg-dark" style="position:relative">
            <div class="container-fluid">
                <a class="navbar-brand">
                <img class="img-responsive" src="gambar/logo.jpg" width="60" height="60" />
                </a>
                <h3 style="color:#ffffff">GIS Pemetaan Mata Air PDAM Wonosobo</h3>
            </div>
        </div>
    </header>
  
    <body>
        <div class="row">
        <div class="col-sm-7">
            <div id="map" style="width: 100%; height: 630px;"></div>
        </div>
        <div class="col-sm-5">
            <div class="form-grup">
                <label>latitude</label>
                <input class="form-control" id="latitude" name="latitude">
            </div>
            <div class="form-grup">
                <label>longitude</label>
                <input class="form-control" id="longitude" name="longitude">
            </div>
            <div class="form-grup">
                <label>Titik Marker</label>
                <input class="form-control" id="lokasi" name="lokasi">
            </div>


        </div>
    </div>

    <script>
        var map = L.map('map').setView([-7.359598, 109.904983], 12);
        var tiles = L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token=pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw', {
        attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors, ' +
        'Imagery © <a href="https://www.mapbox.com/">Mapbox</a>', id: 'mapbox/streets-v11', }).addTo(map);
    //marker
        var icon1 = L.icon({
            iconUrl: 'icon/mataair.png',
            iconSize: [40, 55],
        });
        var icon2 = L.icon({
            iconUrl: 'icon/kantor.png',
            iconSize: [40, 55],
        });

        L.marker([-7.265586308173416,109.84867895221602], {
            icon: icon1
        }).bindPopup("Mata Air Banyu Panas <br>"+
        "Dusun Lamuk, Desa Kalidesel, Kecamatan Watumalang <br>"+
        "<img src='gambar/mabanyupanas.jpg' width='200px'>").addTo(map);
        
        L.marker([-7.313603553327867,109.86446477480982], {
            icon: icon1
        }).bindPopup("Mata Air Lumajang <br>"+
        "Dusun Sumber, Desa Lumajang, Kecamatan Watumalang <br>"+
        "<img src='gambar/malumajang.jpg' width='200px'>").addTo(map);
        
        L.marker([-7.290106395681044,109.89501580998969], {
            icon: icon1
        }).bindPopup("Mata Air Mudal <br>"+
        "Dusun Slukatan, Desa Slukatan, Kecamatan Mojotengah <br>"+
        "<img src='gambar/mamudal.jpg' width='200px'>").addTo(map);
        
        L.marker([-7.3503792289170375,109.89945180130222], {
            icon: icon1
        }).bindPopup("Mata Air Mangli <br>"+
        "Kelurahan Kejiwan, Kecamatan Wonosobo <br>"+
        "<img src='gambar/mamangli.jpg' width='200px'>").addTo(map);

        L.marker([-7.355816578028673,109.90407105834657], {
            icon: icon2
        }).bindPopup("Kantor PDAM Tirta Aji <br>"+
        "Jalan Tirto Aji, Wonosobo <br>"+
        "<img src='gambar/kantorpdam.jpg' width='200px'>").addTo(map);

    //getcoordinat
        var latInput = document.querySelector("[name=latitude]");
        var lngInput = document.querySelector("[name=longitude]");
        var lokasiInput = document.querySelector("[name=lokasi]");

        var curLocation = [-7.359598, 109.904983];

        map.attributionControl.setPrefix(false);

        var marker = new L.marker (curLocation, {
            draggable: 'true'
        });

        marker.on('dragend', function(event) {
            var position = marker.getLatLng();
            marker.setLatLng(position, {
                draggable: 'true'
            }).bindPopup(position).update();
            $("#latitude").val(position.lat);
            $("#longitude").val(position.lng);
            $("#lokasi").val(position.lat + "," + position.lng);
        });
        map.addLayer(marker);

        map.on("click",function(e){
            var lat =e.latlng.lat;
            var lng =e.latlng.lng;
            if (!marker) {
                marker = L.marker(e.latlng).addTo(map);
            } else {
                marker.setLatLng(e.latlng);
            }
            latInput.value=lat;
            lngInput.value=lng;
            lokasiInput.value=lat + "," + lng;
        });

    //polyline
    L.polyline([
            [-7.265586308173416,109.84867895221602],
            [-7.27375981955179,109.84670380414666],
            [-7.277420823274386,109.85099605386459],
            [-7.275377476042087,109.85605518818316],
            [-7.279123605526046,109.85588666450361],
            [-7.2739300994568845,109.86403389199418],
            [-7.277591101790392,109.86669748802149],
            [-7.295725393504035,109.86403389199418],
            [-7.305005099051821,109.858975471223],
            [-7.338376390999624,109.85820000103558],
            [-7.354380102837566,109.87064433497015],
            [-7.344931172441515,109.87535850385493],
            [-7.353613980834948,109.87793735083537],
            [-7.355997467167618,109.89380402481912],
            [-7.3519966078213965,109.89707079245824],
            [-7.348985298951818,109.90129952016416],
            [-7.3516880294061835,109.9028116822781],
            [-7.354582273701095,109.90227483265238],
            [-7.355433518432266,109.90413086014784],
            [-7.355816578028673,109.90407105834657]
        ]).addTo(map);
        L.polyline([
            [-7.313603553327867,109.86446477480982],
            [-7.319137124446275,109.85906431400574],
            [-7.338716901505325,109.85863745371475],
            [-7.354550351991925,109.87064730493391],
            [-7.344931172441515,109.87554102295688],
            [-7.354124728983588,109.87793966863211],
            [-7.356252839944139,109.89390226289993],
            [-7.351964685926316,109.89699116331185],
            [-7.349027861763602,109.90130198778722],
            [-7.351719951321148,109.90278243902064],
            [-7.354571633131631,109.9022457054423],
            [-7.355465440077913,109.90414422762099],
            [-7.355816578028673,109.90407105834657]
        ]).addTo(map);
        L.polyline([
            [-7.290106395681044,109.89501580998969],
            [-7.294874034731048,109.89065529322362],
            [-7.300407837800415,109.89219191479853],
            [-7.3038132210444715,109.89605579273257],
            [-7.308240180477474,109.8984547683276],
            [-7.312667096043428,109.8980291970255],
            [-7.315221065828524,109.89879793838396],
            [-7.317775020999265,109.89579839217264],
            [-7.321010009894656,109.8984547683276],
            [-7.324585496635257,109.89888719889201],
            [-7.32628809928943,109.90343073414518],
            [-7.331055352110406,109.90189020542475],
            [-7.33343895938639,109.90248689372928],
            [-7.345867561901821,109.90051366590505],
            [-7.348889532610443,109.90124865289174],
            [-7.351602904288385,109.90279346001955],
            [-7.354592914270306,109.9022357808649],
            [-7.355497361721285,109.90407980585691],
            [-7.355816578028673,109.90407105834657]
        ]).addTo(map);
        L.polyline([
            [-7.3503792289170375,109.89945180130222],
            [-7.3487512034142055,109.90109840918858],
            [-7.350592042267283,109.90186028385881],
            [-7.351698670044755,109.90284643166329],
            [-7.354646117112566,109.90225710972206],
            [-7.355497361721285,109.90415476750329],
            [-7.355816578028673,109.90407105834657]
        ]).addTo(map);
    
    </script>
  </body>

  <footer class="footer border-top bg-dark">
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-4">
				<div class="copyright" style="color:#ffffff">All Rights Reserved | &copy; Kelompok 8 SIG - TI 2018 B</div>
			</div>
		</div>
	</div>
</footer>

</html>